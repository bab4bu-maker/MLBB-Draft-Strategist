# MLBB Draft Strategist V1

Aplikasi Android fan-made untuk membantu menyusun strategi dari draft Mobile Legends: Bang Bang.

## Fitur V1

- Roster 133 hero referensi September 2026.
- Pilih hingga 5 hero tim sendiri dan 5 hero musuh.
- Analisis strategi utama otomatis berdasarkan pola draft.
- Game plan Early / Mid / Late.
- Ancaman utama dan prioritas target.
- Rekomendasi hero counter berbasis karakter ancaman.
- Catatan komposisi tim.
- Scan screenshot beta memakai OCR on-device untuk membaca **nama hero yang tampak sebagai teks**.
- Offline-first. Analisis strategi tidak mengakses game atau akun MLBB.

> Catatan: V1 belum melakukan computer vision untuk mengenali wajah/icon hero tanpa teks. Itu membutuhkan model klasifikasi gambar khusus dan dataset hero.

## Build APK dengan GitHub Actions

1. Upload seluruh isi folder project ini ke root repository GitHub.
2. Pastikan folder `.github/workflows/build-apk.yml` ikut ter-upload.
3. Buka tab **Actions** di repository.
4. Pilih **Build Android APK**.
5. Pilih **Run workflow**.
6. Setelah workflow berhasil, buka run tersebut lalu ambil artifact **MLBB-Draft-Strategist-APK**.
7. Di dalam ZIP artifact terdapat `app-debug.apk`.

Workflow juga otomatis berjalan setiap ada push ke branch `main` atau `master`.

## Struktur penting

```text
.github/workflows/build-apk.yml
app/build.gradle
app/src/main/AndroidManifest.xml
app/src/main/java/com/akanclip/mlbbdraft/MainActivity.java
app/src/main/assets/index.html
```

## Teknologi

- Android Java + WebView
- Google ML Kit Text Recognition untuk OCR screenshot
- HTML/CSS/JavaScript untuk antarmuka dan strategy engine
- GitHub Actions untuk build APK

## Disclaimer

Fan-made helper. Tidak berafiliasi dengan atau disponsori oleh Moonton. Rekomendasi bersifat alat bantu keputusan dan bukan jaminan kemenangan.
